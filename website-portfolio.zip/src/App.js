import './App.css';
import Summary from './Components/Summary';
import Portfolio from './Components/Portfolio';

function App() {
  return (
    <>
    <div className="portfolio">
      <Summary/>
      {/* <Portfolio/> */}
    </div>
    
    
    </>
  );
}

export default App;
